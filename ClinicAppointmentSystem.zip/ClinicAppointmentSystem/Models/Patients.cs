﻿namespace ClinicAppointmentSystem.Models
{
    public class Patients
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Date { get; set; }
    }
}
